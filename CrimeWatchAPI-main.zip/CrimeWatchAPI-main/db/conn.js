const { MongoClient } = require("mongodb");

const Db = `mongodb+srv://CrimeWatchAdmin:freedomofspeech@cluster0.sjnozy6.mongodb.net/test`

const client = new MongoClient(Db, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

var CWDB;

module.exports = {
    connectToServer: function (callback) {
        client.connect(function (err, db) {
            // Verify we got a good "db" object
            if (db) {
                CWDB = db.db("CrimeWatch");
                console.log("Successfully connected to MongoDB.");
            }
            return callback(err);
        });
    },

    getDB: function () {
        return CWDB;
    }
};