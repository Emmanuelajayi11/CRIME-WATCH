const express = require("express");

const userRoutes = express.Router();

const dbo = require("../db/conn");

const ObjectId = require("mongodb").ObjectId;

const DateTime = require("../services/dateTime")

const isValidEmail = (email) => (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) ? true : false;
const isLettersOnly = (string) => (/^[a-zA-Z]+$/.test(string)) ? true : false;
const isNumbersOnly = (string) => (/^\d+$/.test(string)) ? true : false;

const isValidBadgeNumber = (badgeNumber) => !(!badgeNumber || badgeNumber.length !== 10 || !isNumbersOnly(badgeNumber))

function validateUserData(data) {
    if (!data.firstName || data.firstName.length < 1 || !isLettersOnly(data.firstName)) throw new Error("Missing or Invalid FirstName.")
    if (!data.lastName || data.lastName.length < 1 || !isLettersOnly(data.lastName)) throw new Error("Missing or Invalid LastName.")
    if (!data.phone || data.phone.length !== 11 || !isNumbersOnly(data.phone)) throw new Error("Missing or Invalid Phone.")
    if (!data.email || !isValidEmail(data.email)) throw new Error("Missing or Invalid Email.")
    if (!isValidBadgeNumber(data.badgeNumber)) throw new Error("Missing or Invalid Badge Number.")
    if (!data.residentialAddress || data.residentialAddress.length < 10) throw new Error("Missing or Invalid Residential Address.")
}

// Creates a new user.
userRoutes.route("/create-user").post(async function (req, res) {
    try {
        let db = dbo.getDB();
        const userData = {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            phone: req.body.phone,
            email: req.body.email,
            rank: req.body.rank,
            badgeNumber: req.body.badgeNumber,
            residentialAddress: req.body.residentialAddress,
            unit: req.body.unit,
            role: req.body.role,
            status: "Active",
            password: "12345"
        }

        validateUserData(userData)

        const result = await db.collection("Users").insertOne(userData);

        res.json({
            success: true,
            message: "User created successfully.",
            userID: result.id
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets all users.
userRoutes.route("/get-all-users").get(async function (req, res) {
    try {
        let db = dbo.getDB();

        let page = Math.max(parseInt(req.query.page ? req.query.page : 1), 1);
        let pageSize = parseInt(req.query.pageSize ? req.query.pageSize : 10);
        const skip = (page - 1) * pageSize;

        const filters = {};
        if (req.query.filterRank) filters.rank = req.query.filterRank;
        if (req.query.filterUnit) filters.unit = req.query.filterUnit;
        if (req.query.filterRole) filters.role = req.query.filterRole;
        if (req.query.filterStatus) filters.status = req.query.filterStatus;
        if (req.query.filterBadge) {
            isValidBadgeNumber(req.query.filterBadge)
            filters.badgeNumber = req.query.filterBadge;
        }

        const result = await db.collection("Users").find(filters).skip(skip).limit(pageSize).toArray()
        const users = result.map((user) => {
            return {
                ...user,
                password: ""
            }
        })

        const statData = {
            totalUsers: await db.collection("Users").countDocuments(filters),
            totalActiveUsers: await db.collection("Users").countDocuments({ ...filters, status: "Active" })
        }

        res.json({
            success: true,
            data: result,
            stats: statData
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets a single user.
userRoutes.route("/get-user").get(async function (req, res) {
    try {
        let db = dbo.getDB();
        const params = req.query;

        const result = await db.collection("Users").findOne({ _id: ObjectId(params.id) })

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Updates a single user.
userRoutes.route("/update-user").post(async function (req, res) {
    try {
        let db = dbo.getDB();
        const userData = {}
        if (req.body.firstName) userData.firstName = req.body.firstName
        if (req.body.lastName) userData.lastName = req.body.lastName
        if (req.body.phone) userData.phone = req.body.phone
        if (req.body.email) userData.email = req.body.email
        if (req.body.rank) userData.rank = req.body.rank
        if (req.body.badgeNumber) userData.badgeNumber = req.body.badgeNumber
        if (req.body.residentialAddress) userData.residentialAddress = req.body.residentialAddress
        if (req.body.unit) userData.unit = req.body.unit
        if (req.body.role) userData.role = req.body.role
        if (req.body.status) userData.status = req.body.status

        validateUserData(userData)

        const result = await db.collection("Users").updateOne({ _id: ObjectId(req.body._id) }, {$set: userData});

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Delete a single user.
userRoutes.route("/delete-user").delete(async function (req, res) {
    try {
        let db = dbo.getDB();

        const result = await db.collection("Users").deleteOne({ _id: ObjectId(req.query.id) });

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

module.exports = userRoutes;