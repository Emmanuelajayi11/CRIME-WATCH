const express = require("express");

const criminalRoutes = express.Router();

const dbo = require("../db/conn");

const ObjectId = require("mongodb").ObjectId;

const DateTime = require("../services/dateTime")

const isValidEmail = (email) => (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) ? true : false;
const isLettersOnly = (string) => (/^[a-zA-Z]+$/.test(string)) ? true : false;
const isNumbersOnly = (string) => (/^\d+$/.test(string)) ? true : false;

const isValidNIN = (NIN) => !(!NIN || NIN.length !== 11 || !isNumbersOnly(NIN))

function validateCriminalData(data) {
    if (!data.firstName || data.firstName.length < 1 || !isLettersOnly(data.firstName)) throw new Error("Missing or Invalid FirstName.")
    if (!data.lastName || data.lastName.length < 1 || !isLettersOnly(data.lastName)) throw new Error("Missing or Invalid LastName.")
    if (!data.age || data.age < 18) throw new Error("Missing or Invalid Age.")
    if (!data.occupation || data.occupation.length < 1) throw new Error("Missing or Invalid Occupation.")
    if (!data.aliases || data.aliases.length < 1) throw new Error("Missing or Invalid Alias.")
    if (!data.phone || data.phone.length !== 11 || !isNumbersOnly(data.phone)) throw new Error("Missing or Invalid Phone.")
    if (!data.email || !isValidEmail(data.email)) throw new Error("Missing or Invalid Email.")
    if (isValidNIN(data.NIN)) throw new Error("Missing or Invalid NIN.")
    if (!data.address || data.address.length < 10) throw new Error("Missing or Invalid Residential Address.")
    if (!data.description || data.description.length < 10) throw new Error("Missing or Invalid Description.")
}

// Creates a new criminal.
criminalRoutes.route("/create-criminal").post(async function (req, res) {
    try {
        let db = dbo.getDB();
        const criminalData = {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            age: parseInt(req.body.age),
            gender: req.body.gender,
            nationality: req.body.nationality,
            occupation: req.body.occupation,
            address: req.body.address,
            phone: req.body.phone,
            email: req.body.email,
            crime: req.body.crime,
            NIN: req.body.NIN,
            description: req.body.description,
            aliases: req.body.aliases,
            status: req.body.status
        }

        validateCriminalData(criminalData)

        const result = await db.collection("Criminals").insertOne(criminalData);

        res.json({
            success: true,
            message: "Criminal created successfully.",
            criminalID: result.id
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets all criminals.
criminalRoutes.route("/get-all-criminals").get(async function (req, res) {
    try {
        let db = dbo.getDB();

        let page = Math.max(parseInt(req.query.page ? req.query.page : 1), 1);
        let pageSize = parseInt(req.query.pageSize ? req.query.pageSize : 10);
        const skip = (page - 1) * pageSize;

        const filters = {};
        if (req.query.filterAge) filters.age = { $gt: parseInt(req.query.filterAge), $lt: parseInt(req.query.filterAge) + 10 };
        if (req.query.filterGender) filters.gender = req.query.filterGender;
        if (req.query.filterStatus) filters.status = req.query.filterStatus;
        if (req.query.filterNIN) {
            isValidNIN(req.query.filterNIN)
            filters.NIN = req.query.filterNIN;
        }

        const result = await db.collection("Criminals").find(filters).skip(skip).limit(pageSize).toArray()

        const statData = {
            totalCriminals: await db.collection("Criminals").countDocuments(filters),
            totalFugitiveCriminals: await db.collection("Criminals").countDocuments({ ...filters, status: "Fugitive" }),
            totalInCustodyCriminals: await db.collection("Criminals").countDocuments({ ...filters, status: "In Custody" }),
            totalIncarceratedCriminals: await db.collection("Criminals").countDocuments({ ...filters, status: "Incarcerated" }),
            totalReleasedCriminals: await db.collection("Criminals").countDocuments({ ...filters, status: "Released" }),
            totalDeceasedCriminals: await db.collection("Criminals").countDocuments({ ...filters, status: "Deceased" })
        }

        res.json({
            success: true,
            data: result,
            stats: statData
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets a single criminal.
criminalRoutes.route("/get-criminal-by-id").get(async function (req, res) {
    try {
        let db = dbo.getDB();
        const params = req.query;

        const result = await db.collection("Criminals").findOne({ _id: ObjectId(params.id) })

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets a single criminal by NIN.
criminalRoutes.route("/get-criminal-by-nin").get(async function (req, res) {
    try {
        let db = dbo.getDB();
        const params = req.query;

        isValidNIN(req.query.NIN)

        const result = await db.collection("Criminals").findOne({ NIN: params.NIN })

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Get status count.
criminalRoutes.route("/get-status-count").get(async function (req, res) {
    try {
        let db = dbo.getDB();

        const totalFugitive = await db.collection("Criminals").countDocuments({ status: "Fugitive" });
        const totalDetained = await db.collection("Criminals").countDocuments({ status: "Detained" });
        const totalIncarcerated = await db.collection("Criminals").countDocuments({ status: "Incarcerated" });
        const totalReleased = await db.collection("Criminals").countDocuments({ status: "Released" });
        const totalDeceased = await db.collection("Criminals").countDocuments({ status: "Deceased" });

        const result = {
            totalFugitive,
            totalDetained,
            totalIncarcerated,
            totalReleased,
            totalDeceased
        }

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Updates a single criminal.
criminalRoutes.route("/update-criminal").post(async function (req, res) {
    try {
        let db = dbo.getDB();
        const criminalData = {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            age: parseInt(req.body.age),
            gender: req.body.gender,
            nationality: req.body.nationality,
            occupation: req.body.occupation,
            address: req.body.address,
            phone: req.body.phone,
            email: req.body.email,
            crime: req.body.crime,
            NIN: req.body.NIN,
            description: req.body.description,
            aliases: req.body.aliases,
            status: req.body.status
        }
        
        validateCriminalData(criminalData)

        const result = await db.collection("Criminals").updateOne({ _id: ObjectId(req.body._id) }, {$set: criminalData});

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Delete a single user.
criminalRoutes.route("/delete-criminal").delete(async function (req, res) {
    try {
        let db = dbo.getDB();
        console.log(req.query.id)

        const result = await db.collection("Criminals").deleteOne({ _id: ObjectId(req.query.id) });

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

module.exports = criminalRoutes;