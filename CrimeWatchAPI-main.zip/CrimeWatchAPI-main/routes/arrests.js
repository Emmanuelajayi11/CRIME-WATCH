const express = require("express");

const arrestRoutes = express.Router();

const dbo = require("../db/conn");

const ObjectId = require("mongodb").ObjectId;

const DateTime = require("../services/dateTime")

function getDayOfWeek(dateString) {
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const date = new Date(dateString);
    return daysOfWeek[date.getDay()];
}

function hasDatePassed(dateString) {
    const currentDate = new Date();
    const dateToCheck = new Date(dateString);
    dateToCheck.setHours(0, 0, 0, 0);

    if (dateToCheck < currentDate) {
        // The date has passed
        return true;
    } else if (dateToCheck.getTime() === currentDate.getTime()) {
        // The date is the current date
        return true;
    } else {
        // The date has not yet passed
        return false;
    }
}

const isLettersOnly = (string) => (/^[a-zA-Z]+$/.test(string)) ? true : false;
const isNumbersOnly = (string) => (/^\d+$/.test(string)) ? true : false;

const isValidBadgeNumber = (badgeNumber) => !(!badgeNumber || badgeNumber.length !== 10 || !isNumbersOnly(badgeNumber))
const isValidNIN = (NIN) => !(!NIN || NIN.length !== 11 || !isNumbersOnly(NIN))

function validateArrestData(data) {
    if (!data.criminalsIDs || data.criminalsIDs.length < 1) throw new Error("Missing or Invalid Criminals IDs.")
    if (!isValidBadgeNumber(data.officerBadgeNumber)) throw new Error("Missing or Invalid Badge Number.")
    if (!data.date || !hasDatePassed(data.date)) throw new Error("Missing or Invalid Date.")
    if (!data.time || data.time.length < 1) throw new Error("Missing or Invalid Time.")
    if (data.courtDate && !hasDatePassed(data.date)) throw new Error("Invalid Court Date.")
    if (data.details && data.details.length < 5 || isNumbersOnly(data.details)) throw new Error("Invalid Details.")
    if (data.bailAmount && parseInt(data.bailAmount) < 1) throw new Error("Invalid Bail Amount.")
}

// Creates a new arrest.
arrestRoutes.route("/create-arrest").post(async function (req, res) {
    try {
        let db = dbo.getDB();
        const arrestData = {
            criminalsIDs: req.body.criminalsIDs,
            officerBadgeNumber: req.body.officerBadgeNumber,
            date: req.body.date,
            time: req.body.time,
            location: req.body.location,
            crime: req.body.crime,
            details: req.body.details,
            status: req.body.status,
            courtDate: req.body.courtDate,
            bailAmount: req.body.bailAmount
        }

        validateArrestData(arrestData)

        const result = await db.collection("Arrests").insertOne(arrestData);

        res.json({
            success: true,
            message: "Arrest created successfully.",
            arrestsID: result.id
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets all arrests.
arrestRoutes.route("/get-all-arrests").get(async function (req, res) {
    try {
        let db = dbo.getDB();

        let page = Math.max(parseInt(req.query.page ? req.query.page : 1), 1);
        let pageSize = parseInt(req.query.pageSize ? req.query.pageSize : 10);
        const skip = (page - 1) * pageSize;

        const filters = {};
        if (req.query.filterCriminal) filters.criminal = req.query.filterCrinimal;
        if (req.query.filterOfficer) filters.officer = req.query.filterOfficer;
        if (req.query.filterLocation) filters.location = req.query.filterLocation;
        if (req.query.filterCrime) filters.crime = req.query.filterCrime;
        if (req.query.filterStatus) filters.status = req.query.filterStatus;

        const result = await db.collection("Arrests").find(filters).skip(skip).limit(pageSize).toArray()

        const statData = {
            totalArrests: await db.collection("Arrests").countDocuments(filters)
        }

        res.json({
            success: true,
            data: result,
            stats: statData
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets a single arrest.
arrestRoutes.route("/get-arrest-by-id").get(async function (req, res) {
    try {
        let db = dbo.getDB();
        const params = req.query;

        const result = await db.collection("Arrests").findOne({ _id: ObjectId(params.id) })

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets arrests by criminal.
arrestRoutes.route("/get-arrests-by-criminal").get(async function (req, res) {
    try {
        let db = dbo.getDB();
        let id = req.query.id;
        let page = req.query.page | 1;
        let pageSize = req.query.pageSize | 10;
        const skip = (page - 1) * pageSize;

        const result = await db.collection("Arrests").find({ criminalsIDs: ObjectId(id) }).skip(skip).limit(pageSize).toArray()

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets arrests by crime.
arrestRoutes.route("/get-arrests-by-crime").get(async function (req, res) {
    try {
        let db = dbo.getDB();
        let crime = req.query.crime;
        let page = req.query.page | 1;
        let pageSize = req.query.pageSize | 10;
        const skip = (page - 1) * pageSize;

        const result = await db.collection("Arrests").find({ crime: crime }).skip(skip).limit(pageSize).toArray()

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets all arrests in a week.
arrestRoutes.route("/get-arrests-week").get(async function (req, res) {
    try {
        let db = dbo.getDB();
        const params = req.query;

        const result = await db.collection("Arrests").find({ date: { $gt: params.date } }).toArray()

        const days = []
        const count = []
        for (let record of result) {
            if (!days.includes(record.date)) {
                days.push(record.date);
                count.push((result.filter((item) => item.date === record.date)).length)
            }
        }

        const data = []
        for (let i = 0; i < days.length; i++) {
            data.push([getDayOfWeek(days[i]), count[i]])
        }

        res.json({
            success: true,
            data: data
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Updates a single arrest.
arrestRoutes.route("/update-arrest").post(async function (req, res) {
    try {
        let db = dbo.getDB();
        const arrestData = {
            criminalsIDs: req.body.criminalsIDs,
            officerBadgeNumber: req.body.officerBadgeNumber,
            date: req.body.date,
            time: req.body.time,
            location: req.body.location,
            crime: req.body.crime,
            details: req.body.details,
            status: req.body.status,
            courtDate: req.body.courtDate,
            bailAmount: req.body.bailAmount
        }
        
        validateArrestData(arrestData)

        const result = await db.collection("Arrests").updateOne({ _id: ObjectId(req.body._id) }, { $set: arrestData });

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

module.exports = arrestRoutes;