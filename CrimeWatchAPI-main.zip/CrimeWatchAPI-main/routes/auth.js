const express = require("express");

const authRoutes = express.Router();

const dbo = require("../db/conn");

const ObjectId = require("mongodb").ObjectId;

const DateTime = require("../services/dateTime")

const isValidEmail = (email) => (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) ? true : false;
const isLettersOnly = (string) => (/^[a-zA-Z]+$/.test(string)) ? true : false;
const isNumbersOnly = (string) => (/^\d+$/.test(string)) ? true : false;

const isValidBadgeNumber = (badgeNumber) => !(!badgeNumber || badgeNumber.length !== 10 || !isNumbersOnly(badgeNumber))
const isValidPassword = (password) => (password && password.length >= 8) ? true : false;

// Login Authentication.
authRoutes.route("/login").post(async function (req, res) {
    try {
        let db = dbo.getDB();
        const [badgeNumber, password] = (Buffer.from(req.body.authData, 'base64').toString()).split(":")

        const result = await db.collection("Users").findOne({ badgeNumber: badgeNumber, password: password })

        if (!result) throw new Error("Incorrect Badge Number or Password.")

        res.json({
            success: true,
            data: result
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Change Password.
authRoutes.route("/change-password").post(async function (req, res) {
    try {
        let db = dbo.getDB();
        const badgeNumber = req.body.badgeNumber;
        const oldPass = req.body.old;
        const newPass = req.body.new;

        isValidPassword(newPass)

        const userData = await db.collection("Users").findOne({ badgeNumber: badgeNumber, password: oldPass })

        if (userData) await db.collection("Users").updateOne({ badgeNumber: badgeNumber }, {$set: {password: newPass}})
        else throw new Error("User not found.")

        res.json({
            success: true,
            message: "Password changed successfully."
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

// Gets users statistics.
authRoutes.route("/get-dash-stats").get(async function (req, res) {
    try {
        let db = dbo.getDB();

        const totalUsers = await db.collection("Users").countDocuments();
        const totalActiveUsers = await db.collection("Users").countDocuments({ status: "Active" });
        const totalCriminals = await db.collection("Criminals").countDocuments();
        const totalArrests = await db.collection("Arrests").countDocuments();
        
        const statData = {
            totalUsers,
            totalActiveUsers,
            totalCriminals,
            totalArrests
        }

        res.json({
            success: true,
            data: statData
        })
    } catch (err) {
        res.json({
            success: false,
            error: err.message
        })
    }
})

module.exports = authRoutes;