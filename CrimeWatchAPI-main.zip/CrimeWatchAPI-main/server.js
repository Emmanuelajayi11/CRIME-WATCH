const express = require("express");
const app = express();
const cors = require("cors");
require("dotenv").config({ path: "./config.env" });

const dbo = require("./db/conn");

const authRoutes = require("./routes/auth");
const userRoutes = require("./routes/users");
const criminalRoutes = require("./routes/criminals");
const arrestRoutes = require("./routes/arrests");

const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

const authMiddleware = async (req, res, next) => {
  const db = dbo.getDB();
  const accessToken = (req.header("Authorization"))?.split(" ")[1];
  if (!accessToken) {
    return res.status(401).json({ success: false, message: 'Unauthorized. Are you signed in?' })
  }

  const credentials = Buffer.from(accessToken, 'base64').toString();
  const [badgeNumber, password] = credentials.split(':');

  const result = await db.collection("Users").findOne({ badgeNumber: badgeNumber, password: password })
  if (!result) return res.status(401).json({ success: false, message: "Unauthorized. Are you signed in?" });
  
  return next()
};

app.use("/auth", authRoutes);
app.use("/criminals", authMiddleware, criminalRoutes);
app.use("/arrests", authMiddleware, arrestRoutes);
app.use("/users", authMiddleware, userRoutes);
 
app.listen(port, () => {
  dbo.connectToServer(function (err) {
    if (err) console.error(err);
 
  });
  console.log(`Server is up and running on port: ${port}`);
});